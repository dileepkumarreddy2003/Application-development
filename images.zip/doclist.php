<?php
header('Content-Type: application/json');

// Database credentials
$servername = "your_server_name";
$username = "your_username";
$password = "your_password";
$dbname = "project1";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch doctor details
$sql = "SELECT name, mob, dept, place FROM signup";
$result = $conn->query($sql);

$doctors = array();

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        $doctors[] = $row;
    }
} else {
    echo json_encode(array("message" => "No records found"));
    exit;
}

$conn->close();

echo json_encode($doctors);
?>

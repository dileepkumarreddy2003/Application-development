import * as React from "react";
import {
  FlatList,
  ScrollView,
  View,
  StyleSheet,
  Image,
  Text,
} from "react-native";

function PatientProfile() {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
      </View>
      <View style={styles.content}>
        <View style={styles.infoContainer}>
          <Image
            resizeMode="auto"
            source={{
              uri: "https://cdn.builder.io/api/v1/image/assets/TEMP/7fff0544876a17a54ad0f67939a7855493e0e5cb781ec8164a9da86d78294e78?apiKey=ad53cdad426d4e138d822c19cfb9535b&",
            }}
            style={styles.profileImage}
          />
          <View style={styles.infoRow}>
            <Text style={styles.label}>Patient ID     :</Text>
            <Text style={styles.value}>1234</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.label}>Patient Name:</Text>
            <Text style={styles.value}>abcde</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.label}>Reason:</Text>
            <Text style={styles.value}>Insulin</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.label}>Age:</Text>
            <Text style={styles.value}>43</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.label}>E-mail:</Text>
            <Text style={styles.value}>jbhiwvru@gmail.com</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.label}>Phone Number:</Text>
            <Text style={styles.value}>6466164926</Text>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 2,
    backgroundColor: "#FFF",
    alignItems: "stretch",
    paddingVertical: 100,
    paddingHorizontal: 130,
  },
  header: {
    alignItems: "center",
    marginBottom: 50,
  },
  headerText: {
    fontSize: 30,
    fontWeight: "bold",
    marginTop: 20,
  },
  content: {
    flexDirection: "row",
    alignItems: "center",
  },
  profileImage: {
    width: 148,
    height: 148,
    borderRadius: 64,
    marginRight: 20,
  },
  infoContainer: {
    flex: 1,
    flexDirection: "column",
  },
  infoRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
    width:350,
    marginRight:50,
  },
  label: {
    fontWeight: "bold",
    fontSize: 20,
    marginRight: 10,
  },
  value: {
    flex: 1,
  },
});

export default PatientProfile;



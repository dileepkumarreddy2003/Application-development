<?php
header('Content-Type: application/json');

$doctorId = $_GET['doctorId'];

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project1";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and execute SQL query
$sql = "SELECT pid, date, time, status FROM appt WHERE did = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $doctorId);
$stmt->execute();
$result = $stmt->get_result();

// Fetch data
$appointments = array();
while ($row = $result->fetch_assoc()) {
    $appointments[] = $row;
}

// Close connection
$stmt->close();
$conn->close();

// Output data as JSON
echo json_encode($appointments);
?>

import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput, Image, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';

function PatientLogin() {
  const navigation = useNavigation();

  const [credentials, setCredentials] = useState({ userId: '', password: '' });

  const handleSignIn = async () => {
    try {
      const response = await fetch('http://192.168.220.55/data/PatientLogin.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(credentials),
      });
      const data = await response.json();
      if (data.success) {
        console.log('Login successful:', data);
        navigation.navigate('DemoExercise', { userId: credentials.userId });
      } else {
        Alert.alert('Login failed', data.message);
      }
    } catch (error) {
      console.error('Error:', error);
      Alert.alert('Error', 'Something went wrong. Please try again later.');
    }
  };

  const handleSignUp = () => {
    navigation.navigate('PatientSignup');
  };

  return (
    <LinearGradient colors={['#33EC75', '#fff']} style={styles.container}>
      <View style={styles.view2}>
        <Text style={styles.text1}>Hello patient</Text>
        <Image source={require('./images/doctlog.png')} style={styles.image} />
        <View style={styles.inputContainer}>
          <TextInput
            style={[styles.input, styles.userIdInput]}
            placeholder="Enter User ID"
            value={credentials.userId}
            onChangeText={(text) => setCredentials({ ...credentials, userId: text })}
          />
          <TextInput
            style={[styles.input, styles.passwordInput]}
            placeholder="Enter Password"
            secureTextEntry={true}
            value={credentials.password}
            onChangeText={(text) => setCredentials({ ...credentials, password: text })}
          />
        </View>
        <TouchableOpacity style={styles.signInButton} onPress={handleSignIn}>
          <Text style={styles.signInButtonText}>Sign In</Text>
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 50,
    marginTop: 0,
  },
  view2: {
    borderRadius: 60,
    width: '90%',
    alignItems: 'center',
    padding: 40,
  },
  text1: {
    color: '#FFFFFF',
    textAlign: 'center',
    fontSize: 50,
    fontWeight: 'bold',
    marginTop: -20,
  },
  image: {
    width: 230,
    height: 220,
    alignSelf: 'center',
    marginBottom: 20,
    marginTop: 60,
    borderRadius: 30,
  },
  inputContainer: {
    marginTop: 20,
    alignItems: 'center',
    width: '100%',
  },
  input: {
    width: '100%',
    height: 55,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 20,
    marginBottom: 20,
    backgroundColor: '#FFF',
  },
  signInButton: {
    borderRadius: 20,
    backgroundColor: '#019874',
    marginTop: 40,
    alignItems: 'center',
    justifyContent: 'center',
    width: 250,
    paddingVertical: 14,
    paddingHorizontal: 60,
  },
  signInButtonText: {
    color: '#fff',
    fontSize: 25,
  },
  signUpButton: {
    alignSelf: 'center',
    marginVertical: 20,
  },
  signUpButtonText: {
    color: '#019874',
    fontSize: 18,
  },
});

export default PatientLogin;

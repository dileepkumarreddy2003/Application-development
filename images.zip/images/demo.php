<?php
// Check if form submitted with file upload
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["video_file"])) {
    // Define upload directory
    $target_dir = "uploads/";

    // Get introduction and custom file name from the form
    $introduction = $_POST['introduction'];
    $custom_file_name = $_POST['custom_file_name'];

    // Generate file name
    $video_name = $custom_file_name . "_" . basename($_FILES["video_file"]["name"]);
    $target_file = $target_dir . $video_name;

    // Check file type
    $videoFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    if ($videoFileType != "mp4" && $videoFileType != "avi" && $videoFileType != "mov") {
        echo "Sorry, only MP4, AVI, and MOV files are allowed.";
        exit;
    }

    // Move uploaded file to the target directory
    if (move_uploaded_file($_FILES["video_file"]["tmp_name"], $target_file)) {
        // File uploaded successfully, now insert into database
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "sample";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare SQL statement
        $sql = "INSERT INTO adddoctorvideos (video_name, video_path, introduction, custom_file_name) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        // Bind parameters and execute
        $video_path = $target_file;
        $stmt->bind_param("ssss", $video_name, $video_path, $introduction, $custom_file_name);

        if ($stmt->execute()) {
            echo "Video uploaded successfully.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $stmt->close();
        $conn->close();
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
?>
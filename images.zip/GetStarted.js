import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ImageBackground } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const GetStarted = () => {
  const navigation = useNavigation(); // Initialize navigation

  return (
    <View style={styles.container}>
      <ImageBackground
        source={require('./images/doct.png')}
        style={styles.backgroundImage}
      >
        
      </ImageBackground>
      <Text style={styles.topText}>Consult Specialist Doctors Securely And Privately</Text>
      <Text style={styles.middleText}>
        Welcome to Lumbar Guide - your comprehensive resource for understanding and caring for your lower back.
        Explore anatomy, exercises, and tips to support a healthy lumbar spine.
      </Text>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Welcome')}>
        <Text style={styles.buttonText}>GET STARTED</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  backgroundImage: {
    width: '100%',
    height: 300, // Adjust the height as needed
    justifyContent: 'center',
    marginBottom:-50,
    alignItems: 'center',
  },
  topText: {
    fontSize: 30,
    fontWeight: 'bold',
    marginTop: 80,
    color: '#000000',
    textAlign: 'center',
  },
  middleText: {
    fontSize: 21,
    textAlign: 'center',
    marginHorizontal: 30,
    marginTop: 30,
    marginBottom: 100,
  },
  button: {
    backgroundColor: '#019874',
    paddingVertical: 22,
    paddingHorizontal: 24,
    borderRadius: 20,
  },
  buttonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
});

export default GetStarted;

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projrct1";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$doctorId = $_GET['doctorId'];

$sql = "SELECT userId, name, image FROM logs1 WHERE doctorId = '$doctorId'";
$result = $conn->query($sql);

$patients = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $patients[] = $row;
    }
}

echo json_encode($patients);

$conn->close();
?>

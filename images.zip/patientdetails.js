import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';

const Details = ({ route }) => {
  const { patientId } = route.params;
  const [patientData, setPatientData] = useState(null);

  useEffect(() => {
    fetchPatientData();
  }, []);

  const fetchPatientData = async () => {
    try {
      const response = await fetch(``);
      const data = await response.json();
      setPatientData(data);
    } catch (error) {
      console.error('Error fetching patient data:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Image
         source={require('./images/addpatient.jpg')} // Update with the path to your image
        style={styles.image}
      />
      {patientData && (
        <>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>General Information</Text>
            <View style={styles.infoContainer}>
              <Text style={styles.infoLabel}>Patient ID:</Text>
              <Text style={styles.infoText}>{patientData.logs.Patientid}</Text>
            </View>
            <View style={styles.infoContainer}>
              <Text style={styles.infoLabel}>Username:</Text>
              <Text style={styles.infoText}>{patientData.logs.username}</Text>
            </View>
            <View style={styles.infoContainer}>
              <Text style={styles.infoLabel}>Age:</Text>
              <Text style={styles.infoText}>{patientData.logs.age}</Text>
            </View>
            <View style={styles.infoContainer}>
              <Text style={styles.infoLabel}>Reason for Admit:</Text>
              <Text style={styles.infoText}>{patientData.logs.reasonForAdmit}</Text>
            </View>
          </View>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Health Details</Text>
            <View style={styles.infoContainer}>
              <Text style={styles.infoLabel}>Gender:</Text>
              <Text style={styles.infoText}>{patientData.details.gender}</Text>
            </View>
            <View style={styles.infoContainer}>
              <Text style={styles.infoLabel}>Height:</Text>
              <Text style={styles.infoText}>{patientData.details.height}</Text>
            </View>
            <View style={styles.infoContainer}>
              <Text style={styles.infoLabel}>Weight:</Text>
              <Text style={styles.infoText}>{patientData.details.weight}</Text>
            </View>
          </View>
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  image: {
    width: 250,
    height: 300,
    resizeMode: 'cover',
    marginBottom: 400,
    marginTop: -100,
  },
  section: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 20,
    marginBottom: 20,
    width: '100%',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  infoContainer: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  infoLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    marginRight: 10,
  },
  infoText: {
    fontSize: 16,
  },
});

export default Details;

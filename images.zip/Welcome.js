import React from "react";
import { View, StyleSheet, Image, Text, TouchableOpacity } from "react-native";
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';

function Welcome() {
  const navigation = useNavigation();

  const handleDoctorLogin = () => {
    navigation.navigate('DoctorLogin');
  };

  const handlePatientLogin = () => {
    navigation.navigate('PatientLogin');
  };

  const handleAdminLogin = () => {
    navigation.navigate('AdminLogin');
  }; 
  return (
    <LinearGradient
      colors={['#33EC75', '#fff']}    
      style={styles.container}
    >
      <View style={styles.header}>
        <Text style={styles.headerText}>Welcome</Text>
      </View>
      <Image
        resizeMode="contain"
        source={{
          uri: "https://cdn.builder.io/api/v1/image/assets/TEMP/8f958dd3c4f3cd7255c3ed25d6b2b2173cb1c6b8b8b8c102c35c073f9e1c0cb5?",
        }}
        style={styles.image}
      />
      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.button} onPress={handleDoctorLogin}>
          <Text style={styles.buttonText}>DOCTOR LOGIN</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={handlePatientLogin}>
          <Text style={styles.buttonText}>PATIENT LOGIN</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={handleAdminLogin}>
          <Text style={styles.buttonText}>ADMIN LOGIN</Text>
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  header: {
    backgroundColor: "#FFF",
    paddingVertical: 53,
    paddingHorizontal: 110,
    marginBottom: -11,
    marginTop:30,
  },
  headerText: {
    fontSize: 50,
    fontWeight: "bold",
    color: "#000",
  },
  image: {
    width: "100%",
    height: 300,
    marginBottom: 90, // Adjust the margin as needed
    marginTop: 10,
  },
  buttonContainer: {
    alignItems: "center",
    marginBottom:157,
    elevation:5,
  },
  button: {
    backgroundColor: "#FFF",
    borderRadius: 50,
    paddingVertical: 15,
    paddingHorizontal: 50,
    marginBottom: 27,
  },
  buttonText: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#000",
  },
});

export default Welcome;

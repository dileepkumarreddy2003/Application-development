import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';

const DoctorDetails = ({ route }) => {
  const { date, time, userId } = route.params;
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('http://192.168.229.55/data/doclist.php')
      .then(response => response.json())
      .then(data => {
        setDoctors(data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching data:', error);
        setLoading(false);
      });
  }, []);

  const bookAppointment = (doctorId) => {
    const selectedDoctor = doctors.find(doctor => doctor.docid === doctorId);
    if (!selectedDoctor) {
      console.error('Doctor not found for id:', doctorId);
      return;
    }

    const appointmentDetails = {
      date: date,
      time: time,
      pid: userId,
      dname: selectedDoctor.name,
      did: selectedDoctor.docid,
    };

    fetch('http://192.168.229.55/data/bookappt.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(appointmentDetails),
    })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          Alert.alert('Success', 'Appointment booked successfully');
        } else {
          Alert.alert('Error', 'Failed to book appointment');
        }
      })
      .catch(error => {
        console.error('Error booking appointment:', error);
        Alert.alert('Error', 'An error occurred while booking the appointment');
      });
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <Text>Loading...</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {doctors.map((doctor, index) => (
        <View key={index} style={styles.doctorCard}>
          <View style={styles.detailsContainer}>
            <Text style={styles.doctorName}>{doctor.name}</Text>
            <Text style={styles.doctorInfo}>Mobile: {doctor.mob}</Text>
            <Text style={styles.doctorInfo}>Doctor Id: {doctor.docid}</Text>
            <Text style={styles.doctorInfo}>Department: {doctor.dept}</Text>
            <Text style={styles.doctorInfo}>Place: {doctor.place}</Text>
            <View style={styles.buttonContainer}>
              <TouchableOpacity style={styles.button}>
                <Text style={styles.buttonText}>VIEW PROFILE</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.button}
                onPress={() => bookAppointment(doctor.docid)} // Pass doctor id directly here
              >
                <Text style={styles.buttonText}>BOOK NOW</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#fff',
  },
  headerText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  doctorCard: {
    flexDirection: 'row',
    marginBottom: 20,
    marginTop: 50,
    padding: 15,
    backgroundColor: '#f0f0f0',
    borderRadius: 10,
  },
  detailsContainer: {
    flex: 1,
  },
  doctorName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  doctorInfo: {
    fontSize: 14,
    marginBottom: 5,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  button: {
    backgroundColor: '#0AB7B7',
    padding: 10,
    borderRadius: 5,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
    textAlign: 'center',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default DoctorDetails;

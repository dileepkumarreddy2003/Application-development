import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import axios from 'axios';

function PatientSignup() {
  const navigation = useNavigation();
  const [credentials, setCredentials] = useState({ 
    fullName: '', 
    email: '', 
    mobileNumber: '', 
    gender: '', 
    department: '', 
    workplace: '',
    reg_no: '', 
    password: '', 
    confirmPassword: '' 
  });

  const handleSignUp = async () => {
    if (credentials.password !== credentials.confirmPassword) {
      console.log('Passwords do not match!');
      return;
    }

    try {
      const response = await axios.post('http://192.168.220.55/data/signup.php', credentials);
      console.log(response.data);
      if (response.data.message) {
        navigation.navigate('DoctorLogin');
      } else {
        console.log(response.data.error);
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}
    >
      <LinearGradient colors={['#33EC76', '#fff']} style={styles.container}>
        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <View style={styles.view2}>
            <Text style={styles.text1}>Register with us</Text>
            <Text style={styles.text2}>Your information is safe with us</Text>
            <View style={styles.inputContainer}>
              <TextInput
                style={[styles.input, styles.userIdInput]}
                placeholder="Enter your full name"
                value={credentials.fullName}
                onChangeText={(text) => setCredentials({ ...credentials, fullName: text })}
              />
              <TextInput
                style={[styles.input, styles.regnoInput]}
                placeholder="Enter your reg no"
                value={credentials.reg_no}
                onChangeText={(text) => setCredentials({ ...credentials, reg_no: text })}
              />
              <TextInput
                style={[styles.input, styles.emailInput]}
                placeholder="Enter email"
                value={credentials.email}
                onChangeText={(text) => setCredentials({ ...credentials, email: text })}
              />
              <TextInput
                style={[styles.input, styles.mobileNumberInput]}
                placeholder="Enter mobile number"
                value={credentials.mobileNumber}
                onChangeText={(text) => setCredentials({ ...credentials, mobileNumber: text })}
              />
              <TextInput
                style={[styles.input, styles.genderInput]}
                placeholder="Enter gender"
                value={credentials.gender}
                onChangeText={(text) => setCredentials({ ...credentials, gender: text })}
              />
              <TextInput
                style={[styles.input, styles.departmentInput]}
                placeholder="Enter department"
                value={credentials.department}
                onChangeText={(text) => setCredentials({ ...credentials, department: text })}
              />
              <TextInput
                style={[styles.input, styles.workplaceInput]}
                placeholder="Enter workplace"
                value={credentials.workplace}
                onChangeText={(text) => setCredentials({ ...credentials, workplace: text })}
              />
              <TextInput
                style={[styles.input, styles.passwordInput]}
                placeholder="Enter password"
                secureTextEntry
                value={credentials.password}
                onChangeText={(text) => setCredentials({ ...credentials, password: text })}
              />
              <TextInput
                style={[styles.input, styles.confirmPasswordInput]}
                placeholder="Confirm password"
                secureTextEntry
                value={credentials.confirmPassword}
                onChangeText={(text) => setCredentials({ ...credentials, confirmPassword: text })}
              />
            </View>
            <TouchableOpacity style={styles.signUpButton} onPress={handleSignUp}>
              <Text style={styles.signUpButtonText}>Sign Up</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </LinearGradient>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  view2: {
    borderRadius: 60,
    width: 430,
    alignItems: "center",
    marginBottom: 90,
    padding: 30,
  },
  text1: {
    color: "#000000",
    textAlign: "center",
    fontSize: 40,
    fontWeight: 'bold',
    marginTop: 10,
  },
  text2: {
    color: "#000000",
    textAlign: "center",
    marginTop: 10,
    fontSize: 18,
  },
  inputContainer: {
    marginTop: 10,
    alignItems: 'center',
    width: '100%', // Ensure the input container takes full width
  },
  input: {
    width: '100%', 
    height: 55,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 20,
    marginBottom: 25,
    backgroundColor: '#FFF',
  },
  signUpButton: {
    borderRadius: 20,
    backgroundColor: "#019874",
    marginTop: 20,
    alignItems: "center",
    justifyContent: "center",
    width: 250,
    paddingVertical: 14,
    paddingHorizontal: 60,
  },
  signUpButtonText: {
    color: "#fff",
    fontSize: 25,
  },
});

export default PatientSignup;

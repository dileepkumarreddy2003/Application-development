import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, Alert } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import * as ImagePicker from 'expo-image-picker';

const AddPatient = () => {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [address, setAddress] = useState('');
  const [gender, setGender] = useState('');
  const [emailId, setEmailId] = useState('');
  const [userId, setUserId] = useState('');
  const [imageUri, setImageUri] = useState(null); // State to hold the selected image URI

  const navigation = useNavigation();
  const route = useRoute();
  const { doctorId } = route.params;

  useEffect(() => {
    (async () => {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Permission to access media library is required!');
      }
    })();
  }, []);

  const handleAddPatient = async () => {
    if (!name || !age || !phoneNumber || !gender || !emailId || !address || !userId) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    const patientData = {
      name,
      age: parseInt(age),
      phoneNumber,
      address,
      gender,
      emailId,
      userId,
      doctorId,
    };

    try {
      const formData = new FormData();
      formData.append('name', patientData.name);
      formData.append('age', patientData.age.toString());
      formData.append('gender', patientData.gender);
      formData.append('phoneNumber', patientData.phoneNumber);
      formData.append('emailId', patientData.emailId);
      formData.append('address', patientData.address);
      formData.append('userId', patientData.userId);
      formData.append('doctorId', patientData.doctorId);

      if (imageUri) {
        formData.append('image', {
          uri: imageUri,
          name: 'image.jpg',
          type: 'image/jpeg',
        });
      }

      const response = await fetch('http://192.168.220.55/data/patientprofile.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        body: formData,
      });

      const responseData = await response.json();

      if (response.ok) {
        Alert.alert('Success', 'Patient added successfully');
        navigation.navigate('PatientList');
      } else {
        Alert.alert('Error', responseData.message || 'Failed to add patient');
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to connect to server');
      console.error('Error:', error);
    }
  };

  const pickImage = async () => {
    try {
      const pickerResult = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.All,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 1,
      });
  
      if (!pickerResult.cancelled && pickerResult.assets.length > 0 && pickerResult.assets[0].uri) {
        setImageUri(pickerResult.assets[0].uri);
      } else {
        console.log('Image selection canceled or failed.');
      }
    } catch (error) {
      console.error('Error picking image:', error);
    }
  };
  
  return (
    <View style={styles.container}>
      <TouchableOpacity
        onPress={() => navigation.navigate('DoctorDashboard')}
        style={styles.backButton}
      >
        <FontAwesome name="arrow-left" size={24} color="black" />
      </TouchableOpacity>

      <View style={styles.imageContainer}>
        {imageUri && (
          <Image source={{ uri: imageUri }} style={styles.photo} />
        )}

        <TouchableOpacity style={styles.pickImageButton} onPress={pickImage}>
          <Text style={styles.buttonText}>Pick Image</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.form}>
        <TextInput
          style={styles.input}
          placeholder="Name"
          value={name}
          onChangeText={setName}
        />
        <TextInput
          style={styles.input}
          placeholder="Age"
          value={age}
          onChangeText={setAge}
          keyboardType="numeric"
        />
        <TextInput
          style={styles.input}
          placeholder="Gender"
          value={gender}
          onChangeText={setGender}
        />
        <TextInput
          style={styles.input}
          placeholder="Phone Number"
          value={phoneNumber}
          onChangeText={setPhoneNumber}
          keyboardType="phone-pad"
        />
        <TextInput
          style={styles.input}
          placeholder="Password"
          value={emailId}
          onChangeText={setEmailId}
          keyboardType="email-address"
        />
        
        <TextInput
          style={styles.input}
          placeholder="User ID"
          value={userId}
          onChangeText={setUserId}
        />
      </View>

      <TouchableOpacity style={styles.addButton} onPress={handleAddPatient}>
        <Text style={styles.buttonText}>Add Patient</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  backButton: {
    alignSelf: 'flex-start',
    marginBottom: 15,
  },
  imageContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  photo: {
    width: 150, 
    height: 150,
    marginBottom: 10,
    borderRadius: 80,
  },
  pickImageButton: {
    borderRadius: 50,
    paddingVertical: 10,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  form: {
    marginTop: 20,
  },
  input: {
    height: 45,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    marginBottom: 15,
  },
  addButton: {
    marginTop: -10,
    backgroundColor: '#60CA64',
    borderRadius: 50,
    paddingVertical: 10,
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 18,
    color: 'black',
    fontWeight: 'bold',
  },
});

export default AddPatient;

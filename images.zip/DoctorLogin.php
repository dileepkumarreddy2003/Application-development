<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Content-Type: application/json");

$response = array();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (isset($data['userId']) && isset($data['password'])) {
        $userId = $data['userId'];
        $password = $data['password'];

        // Database connection
        $servername = "localhost";
        $username = "root";
        $db_password = "";
        $dbname = "project1";

        $conn = new mysqli($servername, $username, $db_password, $dbname);

        if ($conn->connect_error) {
            $response['success'] = false;
            $response['message'] = "Connection failed: " . $conn->connect_error;
        } else {
            $stmt = $conn->prepare("SELECT * FROM doctors WHERE user_id = ? AND password = ?");
            $stmt->bind_param("ss", $userId, $password);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $response['success'] = true;
                $response['message'] = "Login successful";
                $response['user'] = $result->fetch_assoc();
            } else {
                $response['success'] = false;
                $response['message'] = "Invalid credentials";
            }

            $stmt->close();
            $conn->close();
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Required fields are missing";
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method";
}

echo json_encode($response);
?>

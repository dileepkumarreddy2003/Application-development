import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Video } from 'expo-av';

const L2Spine = () => {
  const [movementCheckedIndex, setMovementCheckedIndex] = useState(null); // Single selected index for movement
  const [sensationCheckedIndex, setSensationCheckedIndex] = useState(null); // Single selected index for sensation
  const [latestVideo, setLatestVideo] = useState(null); // State to hold the latest video object

  useEffect(() => {
    fetchLatestVideo();
  }, []);

  const fetchLatestVideo = async () => {
    try {
      const response = await fetch('http://192.168.220.55/data/l1.php');
      if (!response.ok) {
        throw new Error('Failed to fetch latest video');
      }
      const data = await response.json();
      if (data.success && data.data.length > 0) {
        setLatestVideo(data.data[0]); // Set the first video from the array as the latest video
      } else {
        console.error('No videos available');
      }
    } catch (error) {
      console.error('Error fetching latest video:', error);
    }
  };

  const renderVideoPlayer = () => {
    if (latestVideo) {
      return (
        <View style={styles.videoContainer}>
          <Video
            source={{ uri: latestVideo.video_path }}
            style={styles.video}
            useNativeControls
            resizeMode="contain"
            isLooping
          />
        </View>
      );
    } else {
      return (
        <View style={styles.videoPlaceholder}>
          <Text>No video available</Text>
        </View>
      );
    }
  };

  const handleMovementCheckboxPress = (index) => {
    setMovementCheckedIndex(index);
  };

  const handleSensationCheckboxPress = (index) => {
    setSensationCheckedIndex(index);
  };

  const handleSubmit = () => {
    console.log('Form submitted!');
    console.log('Movement checked index:', movementCheckedIndex);
    console.log('Sensation checked index:', sensationCheckedIndex);
    // Add your logic to handle submission (e.g., send data to backend)
  };

  return (
    <View style={styles.container}>
      {/* Background and top section */}
      <View style={styles.backgroundTop}>
        <Text style={styles.title}>L4-Lumbar Vertebrae</Text>
        {renderVideoPlayer()}
      </View>

      {/* Movement level */}
      <View style={styles.movementLevel}>
        <Text style={styles.subtitle}>Movement Level</Text>

        <View style={styles.ratingContainer}>
          <View style={styles.ratingItem}>
            <Text style={styles.ratingText}>No Movement </Text>
          </View>
          <View style={styles.box}>
            <Text style={styles.ratingsText}> 0/5</Text>
            <TouchableOpacity
              style={[styles.checkbox, movementCheckedIndex === 0 && { backgroundColor: 'white' }]}
              onPress={() => handleMovementCheckboxPress(0)}
            >
              {movementCheckedIndex === 0 && <Text style={[styles.tickMark, { fontSize: 30 }]}>✓</Text>}
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.ratingContainer}>
          <View style={styles.ratingItem}>
            <Text style={styles.ratingText}>Flicker </Text>
          </View>
          <View style={styles.box}>
            <Text style={styles.ratingsText}> 1/5</Text>
            <TouchableOpacity
              style={[styles.checkbox, movementCheckedIndex === 1 && { backgroundColor: 'white' }]}
              onPress={() => handleMovementCheckboxPress(1)}
            >
              {movementCheckedIndex === 1 && <Text style={[styles.tickMark, { fontSize: 30 }]}>✓</Text>}
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.ratingContainer}>
          <View style={styles.ratingItem}>
            <Text style={styles.ratingText}>Against Gravity </Text>
          </View>
          <View style={styles.box}>
            <Text style={styles.ratingsText}> 2/5 </Text>
            <TouchableOpacity
              style={[styles.checkbox, movementCheckedIndex === 2 && { backgroundColor: 'white' }]}
              onPress={() => handleMovementCheckboxPress(2)}
            >
              {movementCheckedIndex === 2 && <Text style={[styles.tickMark, { fontSize: 30 }]}>✓</Text>}
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.ratingContainer}>
          <View style={styles.ratingItem}>
            <Text style={styles.ratingText}>Eliminating Gravity </Text>
          </View>
          <View style={styles.box}>
            <Text style={styles.ratingsText}> 3/5 </Text>
            <TouchableOpacity
              style={[styles.checkbox, movementCheckedIndex === 3 && { backgroundColor: 'white' }]}
              onPress={() => handleMovementCheckboxPress(3)}
            >
              {movementCheckedIndex === 3 && <Text style={[styles.tickMark, { fontSize: 30 }]}>✓</Text>}
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.ratingContainer}>
          <View style={styles.ratingItem}>
            <Text style={styles.ratingText}>Against Resistance </Text>
          </View>
          <View style={styles.box}>
            <Text style={styles.ratingsText}> 4/5 </Text>
            <TouchableOpacity
              style={[styles.checkbox, movementCheckedIndex === 4 && { backgroundColor: 'white' }]}
              onPress={() => handleMovementCheckboxPress(4)}
            >
              {movementCheckedIndex === 4 && <Text style={[styles.tickMark, { fontSize: 30 }]}>✓</Text>}
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.ratingContainer}>
          <View style={styles.ratingItem}>
            <Text style={styles.ratingText}>Full Power </Text>
          </View>
          <View style={styles.box}>
            <Text style={styles.ratingsText}> 5/5 </Text>
            <TouchableOpacity
              style={[styles.checkbox, movementCheckedIndex === 5 && { backgroundColor: 'white' }]}
              onPress={() => handleMovementCheckboxPress(5)}
            >
              {movementCheckedIndex === 5 && <Text style={[styles.tickMark, { fontSize: 30 }]}>✓</Text>}
            </TouchableOpacity>
          </View>
        </View>

        {/* Add similar blocks for other checkboxes */}
      </View>

      {/* Sensation section */}
      <View style={styles.sensationSection}>
        <Text style={styles.subtitle}>Sensation</Text>

        <View style={styles.sensationContainer}>
          <View style={styles.sensationItem}>
            <Text style={styles.sensationText}>Intact</Text>
          </View>
          <View style={styles.box}>
            <TouchableOpacity
              style={[styles.checkbox, sensationCheckedIndex === 6 && { backgroundColor: 'white' }]}
              onPress={() => handleSensationCheckboxPress(6)}
            >
              {sensationCheckedIndex === 6 && <Text style={[styles.tickMark, { fontSize: 30 }]}>✓</Text>}
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.sensationContainer}>
          <View style={styles.sensationItem}>
            <Text style={styles.sensationText}>Diminished</Text>
          </View>
          <View style={styles.box}>
            <TouchableOpacity
              style={[styles.checkbox, sensationCheckedIndex === 7 && { backgroundColor: 'white' }]}
              onPress={() => handleSensationCheckboxPress(7)}
            >
              {sensationCheckedIndex === 7 && <Text style={[styles.tickMark, { fontSize: 30 }]}>✓</Text>}
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.sensationContainer}>
          <View style={styles.sensationItem}>
            <Text style={styles.sensationText}>No Sensation</Text>
          </View>
          <View style={styles.box}>
            <TouchableOpacity
              style={[styles.checkbox, sensationCheckedIndex === 8 && { backgroundColor: 'white' }]}
              onPress={() => handleSensationCheckboxPress(8)}
            >
              {sensationCheckedIndex === 8 && <Text style={[styles.tickMark, { fontSize: 30 }]}>✓</Text>}
            </TouchableOpacity>
          </View>
        </View>

        {/* Add similar blocks for other checkboxes */}
      </View>

      {/* Submit button */}
      <View style={styles.recent}>
        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
          <Text style={styles.submitText}>Submit</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    padding: 20,
  },
  backgroundTop: {
    marginBottom: 10,
  },
  title: {
    fontSize: 25,
    fontWeight: 'bold',
    marginBottom: 30,
    marginTop: 35,
    marginLeft: 24,
  },
  videoContainer: {
    marginBottom: 20,
  },
  video: {
    width: '100%',
    height: 210, // Adjust height as needed
  },
  videoPlaceholder: {
    width: '100%',
    height: 210, // Adjust height as needed
    backgroundColor: 'lightgray',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  movementLevel: {
    padding: 2,
    marginBottom: 10,
  },
  subtitle: {
    width: '52%',
    paddingVertical: 10,
    paddingHorizontal: 8,
    borderRadius: 15,
    fontSize: 25,
    backgroundColor: "#D9E7FF",
    fontWeight: 'bold',
    marginBottom: 7,
    marginTop: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ratingContainer: {
    flexDirection: "row",
    alignItems: 'center',
    justifyContent: "center",
    marginLeft: 0,
    marginBottom: 10,
  },
  ratingItem: {
    flex: 1,
    justifyContent: "center",
    width: "24%",
    height: 30,
  },
  ratingText: {
    flexDirection: "row",
    flex: 1,
    fontSize: 20,
    marginLeft: 0,
  },
  box: {
    flexDirection: "row",
    width: "30%",
    backgroundColor: "white",
    alignItems: 'center',
    justifyContent: "center",
  },
  ratingsText: {
    flex: 1,
    fontSize: 20,
    marginLeft: 25,
  },
  checkbox: {
    width: 30,
    height: 30,
    borderWidth: 1,
    alignItems: 'center',
    borderColor: 'black',
    marginRight: 12,
  },
  tickMark: {
    fontSize: 20,
  },
  sensationSection: {
    marginBottom: 20,
  },
  sensationContainer: {
    flexDirection: "row",
    alignItems: 'center',
    justifyContent: "center",
    marginLeft: 0,
    marginBottom: 10,
  },
  sensationItem: {
    flex: 1,
    justifyContent: "center",
    width: "24%",
    height: 30,
  },
  sensationText: {
    flexDirection: "row",
    flex: 1,
    fontSize: 20,
    marginLeft: 0,
  },
  submitButtonContainer: {
    alignItems: 'center',
  },
  submitButton: {
    backgroundColor: 'blue',
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 25,
    alignItems: 'center',
  },
  submitText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default L2Spine;

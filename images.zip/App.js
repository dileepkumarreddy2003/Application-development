// App.js
import React from 'react';
import { LinearGradient } from 'expo-linear-gradient';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import GetStarted from './GetStarted';
import Welcome from './Welcome';
import DoctorLogin from './DoctorLogin'; 
import Doctordashboard from './Doctordashboard'; 
import PatientLogin from './PatientLogin';
import AdminLogin from './AdminLogin';
import PatientSignup from './PatientSignup';
import DemoExercise from './DemoExercise';
import PatientDashboard from './PatientDashboard';
import ViewAll from './ViewAll';
import PatientProfile from './PatientProfile';
import L2Spine from './L2Spine';
import L3Spine from './L3Spine';
import L4Spine from './L4Spine';
import L5Spine from './L5Spine';
import S1Spine from './S1Spine';
import S2Spine from './S2Spine';
import PatientAppointment from './PatientAppointment';
import Doctorlist from './Doctorlist';
import Admindash from './Admindash';
import Patientlist from './Patientlist';
import Addpatient from './Addpatient';
import patientdetails from './patientdetails';
import addvideos from './addvideos';
import all from './all';
 
const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="GetStarted" component={GetStarted} options={{ headerShown: false }} />
        <Stack.Screen name="Welcome" component={Welcome} options={{ headerShown: false }} />
        <Stack.Screen name="DoctorLogin" component={DoctorLogin} options={{ headerShown: true,headerStyle: {},headerTitle: "                ",marginBottom: 0,headerTitleStyle: {textAlign: 'center',flexGrow: 0, color: 'white'},headerTintColor: 'black',}}/>
        <Stack.Screen name="Doctordashboard" component={Doctordashboard} options={{ headerShown: false }} />
        <Stack.Screen name="PatientLogin" component={PatientLogin} options={{ headerShown: true,headerStyle: {},headerTitle: "                ",marginBottom: 0,headerTitleStyle: {textAlign: 'center',flexGrow: 0, color: 'white'},headerTintColor: 'black',}}/>
        <Stack.Screen name="AdminLogin" component={AdminLogin} options={{ headerShown: false }} />
        <Stack.Screen name="PatientSignup" component={PatientSignup} options={{ headerShown: true,headerStyle: {},headerTitle: "                ",marginBottom: 0,headerTitleStyle: {textAlign: 'center',flexGrow: 0, color: 'white'},headerTintColor: 'black',}}/>
        <Stack.Screen name="DemoExercise" component={DemoExercise} options={{ headerShown: true,headerStyle: {backgroundColor: 'white'},headerTitle: " Exercise Videos",marginBottom: 0,headerTitleStyle: {textAlign: 'center',flexGrow: 1, color: 'black',marginTop:-2,fontSize: 40,fontWeight: 'bold',},headerTintColor: 'black',}}/>
        <Stack.Screen name="PatientDashboard" component={PatientDashboard} options={{ headerShown: false }} />
        <Stack.Screen name="ViewAll" component={ViewAll} options={{ headerShown: true,headerStyle: {backgroundColor: 'white'},headerTitle: " LS Spine Levels",marginBottom: 0,headerTitleStyle: {textAlign: 'center',flexGrow: 1, color: 'black',marginTop:-2,fontSize: 40,fontWeight: 'bold',},headerTintColor: 'black',}}/>
        <Stack.Screen name="PatientProfile" component={PatientProfile} options={{ headerShown: false }} />
        <Stack.Screen name="L2Spine" component={L2Spine} options={{ headerShown: false }} />
        <Stack.Screen name="L3Spine" component={L3Spine} options={{ headerShown: false }} />
        <Stack.Screen name="L4Spine" component={L4Spine} options={{ headerShown: false }} />
        <Stack.Screen name="L5Spine" component={L5Spine} options={{ headerShown: false }} />
        <Stack.Screen name="S1Spine" component={S1Spine} options={{ headerShown: false }} />
        <Stack.Screen name="S2Spine" component={S2Spine} options={{ headerShown: false }} />
        <Stack.Screen name="PatientAppointment" component={PatientAppointment} options={{ headerShown: true,headerStyle: {backgroundColor: 'white'},headerTitle: "    Appointment",marginBottom: 0,headerTitleStyle: {textAlign: 'center',flexGrow: 1, color: 'black',marginTop:-2,fontSize: 40,fontWeight: 'bold',},headerTintColor: 'black',}}/>
        <Stack.Screen name="Doctorlist" component={Doctorlist} options={{ headerShown: false }} />
        <Stack.Screen name="Admindash" component={Admindash} options={{ headerShown: false }} />
        <Stack.Screen name="Patientlist" component={Patientlist} options={{ headerShown: true,headerStyle: {backgroundColor: 'white'},headerTitle: "    Patient List",marginBottom: 0,headerTitleStyle: {textAlign: 'center',flexGrow: 1, color: 'black',marginTop:10,left: 35,fontSize: 30,fontWeight: 'bold',},headerTintColor: 'black',}}/>
        <Stack.Screen name="Addpatient" component={Addpatient} options={{ headerShown: true,headerStyle: {backgroundColor: 'white'},headerTitle: "    Add Patient",marginBottom: 0,headerTitleStyle: {textAlign: 'center',flexGrow: 1, color: 'black',marginTop:10,left: 35,fontSize: 30,fontWeight: 'bold',},headerTintColor: 'black',}}/>
        <Stack.Screen name="patientdetails" component={patientdetails} options={{ headerShown: true,headerStyle: {backgroundColor: 'white'},headerTitle: "    Patient details",marginBottom: 0,headerTitleStyle: {textAlign: 'center',flexGrow: 1, color: 'black',marginTop:10,left: 35,fontSize: 30,fontWeight: 'bold',},headerTintColor: 'black',}}/>
        <Stack.Screen name="addvideos" component={addvideos} options={{ headerShown: false }} />
        <Stack.Screen name="all" component={all} options={{ headerShown: true,headerStyle: {backgroundColor: 'white'},headerTitle: "    Appointments",marginBottom: 0,headerTitleStyle: {textAlign: 'center',flexGrow: 1, color: 'black',marginTop:10,left: 35,fontSize: 30,fontWeight: 'bold',},headerTintColor: 'black',}}/>

      
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

// Import your local images
import Image6 from './images/adlog.png';


const AdminDashBoard = ({ navigation }) => {
  const handleDoctorPasswordPress = () => {
    // Navigate to AdminDash.js when "ADD DOCTOR PASSWORD" is pressed
    navigation.navigate('admindash');
  };

  return (
    <View style={[styles.container, { backgroundColor: 'white' }]}>
      <View style={styles.image6Container}>
        <Image source={Image6} style={styles.image6} />
      </View>
      <TouchableOpacity onPress={handleDoctorPasswordPress}>
        <Text style={styles.doc}>ADD DOCTOR PASSWORD</Text>
      </TouchableOpacity>
      <Text style={styles.pass}>ADD PATIENT PASSWORD</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  image6Container: {
    position: 'absolute',
    top: 300,
    left: 30,
    borderColor: 'green',
    borderWidth: 2,
    borderRadius: 10,
    marginTop: -190,
    padding: 2,
    marginLeft: 24,
  },
  image7Container: {
    position: 'absolute',
    top: 300,
    right: 30,
    borderColor: 'green',
    borderWidth: 2,
    borderRadius: 10,
    padding: 2,
    marginTop: 50,
    marginRight: 90,
  },
  image6: {
    width: 300,
    height: 300,
    resizeMode: 'cover',
  },
  image7: {
    width: 130,
    height: 130,
    resizeMode: 'cover',
  },
  doc: {
    position: 'absolute',
    top: 424,
    fontWeight: 'bold',
    left: 30,
    fontSize: 13,
    textAlign: 'center',
    marginLeft: -118,
    marginTop: -536,
  },
  pass: {
    position: 'absolute',
    top: 424,
    right: 30,
    fontWeight: 'bold',
    fontSize: 13,
    textAlign: 'center',
    marginRight: 76,
    marginTop: 36,
  },
});

export default AdminDashBoard;
// ViewAll.js
import React from 'react';
import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';

function ViewAll() {
  const navigation = useNavigation();

  const handlePressL2 = () => { 
    navigation.navigate('L2Spine');
  };
  
  const handlePressL3 = () => {
    navigation.navigate('L3Spine');
  };

  const handlePressL4 = () => {
    navigation.navigate('L4Spine');
  };

  const handlePressL5 = () => {
    navigation.navigate('L5Spine');
  };

  const handlePressS1 = () => {
    navigation.navigate('S1Spine');
  };

  const handlePressS2 = () => {
    navigation.navigate('S2Spine');
  };

  return (
    <LinearGradient colors={['#33EC76', '#fff']} style={styles.container}>
      <View style={styles.view2}>
        <View style={styles.inputContainer}>
          <TouchableOpacity
            style={styles.input}
            onPress={handlePressL2}
          >
            <Text style={styles.buttonText}>L2 - Lumbar Vertebrae</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.input}
            onPress={handlePressL3}
          >
            <Text style={styles.buttonText}>L3 - Lumbar Vertebrae</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.input}
            onPress={handlePressL4}
          >
            <Text style={styles.buttonText}>L4 - Lumbar Vertebrae</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.input}
            onPress={handlePressL5}
          >
            <Text style={styles.buttonText}>L5 - Lumbar Vertebrae</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.input}
            onPress={handlePressS1}
          >
            <Text style={styles.buttonText}>S1 - Lumbar Vertebrae</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.input}
            onPress={handlePressS2}
          >
            <Text style={styles.buttonText}>S2 - Lumbar Vertebrae</Text>
          </TouchableOpacity>
        </View>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  view2: {
    borderRadius: 60,
    width: '100%',
    height: '100%',
    alignItems: 'center',
    padding: 50,
  },
  inputContainer: {
    alignItems: 'center',
  },
  input: {
    height: 60,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 60,
    marginBottom: 50,
    backgroundColor: '#FFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    color: '#000',
    fontSize: 20,
    fontWeight: 'bold',
  },
});

export default ViewAll;

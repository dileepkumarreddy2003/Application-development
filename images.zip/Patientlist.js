import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TextInput, StyleSheet, TouchableOpacity, Image } from 'react-native';
import axios from 'axios';
import { useNavigation, useRoute } from '@react-navigation/native';

const PatientList = () => {
  const [patients, setPatients] = useState([]);
  const [searchText, setSearchText] = useState('');
  const [error, setError] = useState(null);
  const [selectedPatientId, setSelectedPatientId] = useState(null);
  const navigation = useNavigation();
  const route = useRoute();
  const doctorId = route.params.doctorId;

  useEffect(() => {
    fetchPatients();
  }, []);

  const fetchPatients = () => {
    axios.get(`http://192.168.220.55/data/fetch_data.php?doctorId=${doctorId}`)
      .then(response => {
        if (response.data.status === "success" && Array.isArray(response.data.data)) {
          const patientsWithImageURL = response.data.data.map(patient => ({
            ...patient,
            image: { uri: patient.image_path }
          }));
          setPatients(patientsWithImageURL);
        } else {
          console.error('Invalid response data:', response.data);
          setError(new Error('Invalid response data'));
        }
      })
      .catch(error => {
        console.error('Error fetching patients:', error);
        setError(error);
      });
  };

  const filteredPatients = searchText
    ? patients.filter(patient => patient.userId.toLowerCase().includes(searchText.toLowerCase()))
    : patients;

  const onPatientPress = (patientId) => {
    setSelectedPatientId(selectedPatientId === patientId ? null : patientId);
  };

  const renderPatientDetails = (patient) => {
    return (
      <View style={styles.patientDetailsContainer}>
        <Image
          source={{ uri: patient.image_path }}
          style={styles.patientImageLarge}
          onError={() => console.error('Error loading image')}
          defaultSource={require('./images/pati.png')}
        />
        <Text style={styles.patientID}>Patient ID: {patient.userId}</Text>
        <Text style={styles.patientName}>Name: {patient.name}</Text>
        <Text style={styles.patientAge}>Age: {patient.age}</Text>
        <Text style={styles.patientAge}>Gender: {patient.gender}</Text>
        <Text style={styles.patientAge}>Phone No: {patient.phn}</Text>
        {/* Add more patient details here as needed */}
      </View>
    );
  };

  const renderPatients = () => {
    if (filteredPatients.length === 0) {
      return <Text style={styles.noResults}>No results found.</Text>;
    }

    return filteredPatients.map((patient, index) => (
      <View key={index}>
        <TouchableOpacity style={styles.patientItem} onPress={() => onPatientPress(patient.userId)}>
          <Image
            source={patient.image}
            style={styles.patientImage}
            onError={() => console.error('Error loading image')}
            defaultSource={require('./images/pati.png')} // Provide a default image
          />
          <View style={styles.patientInfo}>
            <Text style={styles.patientID}>Patient ID: {patient.userId}</Text>
            <Text style={styles.patientName}>Name: {patient.name}</Text>
            <Text style={styles.patientAge}>Age: {patient.age}</Text>
          </View>
        </TouchableOpacity>
        {selectedPatientId === patient.userId && renderPatientDetails(patient)}
      </View>
    ));
  };

  return (
    <View style={styles.container}>
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchBar}
          placeholder="Search Patient ID"
          onChangeText={(text) => setSearchText(text)}
          value={searchText}
        />
      </View>
      {error ? (
        <Text style={styles.errorText}>Error fetching patients: {error.message}</Text>
      ) : (
        <ScrollView style={styles.scrollView}>
          {renderPatients()}
        </ScrollView>
      )}
      <TouchableOpacity style={styles.addButton} onPress={() => navigation.navigate('Addpatient', { doctorId: doctorId })}>
        <Text style={styles.addButtonText}>Add Patient</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  searchContainer: {
    marginTop: 40,
    marginBottom: 30,
  },
  searchBar: {
    borderWidth: 1,
    borderColor: '#000',
    padding: 10,
  },
  addButton: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    backgroundColor: 'blue',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  addButtonText: {
    color: 'white',
    fontSize: 16,
  },
  scrollView: {
    flex: 1,
  },
  patientItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
  },
  patientImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  patientImageLarge: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignSelf: 'center',
    marginBottom: 20,
  },
  patientInfo: {
    flex: 1,
  },
  patientID: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  patientName: {
    fontSize: 14,
  },
  patientAge: {
    fontSize: 14,
  },
  patientDetailsContainer: {
    padding: 20,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginTop: 10, // Change marginTop to 10 to appear immediately under the patient container
  },
  noResults: {
    textAlign: 'center',
    marginTop: 20,
  },
  errorText: {
    color: 'red',
    textAlign: 'center',
    marginTop: 20,
  },
});

export default PatientList;

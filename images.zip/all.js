import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, ScrollView, TouchableOpacity, Image } from 'react-native';

const AppointmentsList = ({ appointments }) => (
  <FlatList
    data={appointments}
    keyExtractor={(item) => item.pid.toString()}
    renderItem={({ item }) => (
      <View style={styles.appointmentCard}>
        <View style={styles.imageContainer}>
          <Image
            source={{ uri: item.image || 'https://via.placeholder.com/50' }} // Placeholder image
            style={styles.image}
          />
        </View>
        <View style={styles.appointmentDetails}>
          <Text style={styles.appointmentText}>Patient ID: {item.pid}</Text>
          <Text style={styles.appointmentText}>Date: {item.date}</Text>
          <Text style={styles.appointmentText}>Time: {item.time}</Text>
        </View>
      </View>
    )}
  />
);

const AllAppointments = ({ route }) => {
  const { doctorId } = route.params;
  const [appointments, setAppointments] = useState([]);
  const [selectedStatus, setSelectedStatus] = useState('accepted'); // Default to 'accepted'

  useEffect(() => {
    fetchAppointments();
  }, []);

  const fetchAppointments = async () => {
    try {
      const response = await fetch(`http://192.168.220.55/data/accept.php?doctorId=${doctorId}`);
      const data = await response.json();
      setAppointments(data);
    } catch (error) {
      console.error('Error fetching appointments:', error);
    }
  };

  const filterAppointments = (status) => {
    return appointments.filter(appointment => appointment.status === status);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={[styles.button, selectedStatus === 'accepted' && styles.buttonActive]}
          onPress={() => setSelectedStatus('accepted')}
        >
          <Text style={[styles.buttonText, selectedStatus === 'accepted' && styles.buttonTextActive]}>Accepted</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.button, selectedStatus === 'rejected' && styles.buttonActive]}
          onPress={() => setSelectedStatus('rejected')}
        >
          <Text style={[styles.buttonText, selectedStatus === 'rejected' && styles.buttonTextActive]}>Rejected</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.button, selectedStatus === 'pending' && styles.buttonActive]}
          onPress={() => setSelectedStatus('pending')}
        >
          <Text style={[styles.buttonText, selectedStatus === 'pending' && styles.buttonTextActive]}>Pending</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <AppointmentsList appointments={filterAppointments(selectedStatus)} />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  button: {
    flex: 1,
    marginHorizontal: 4,
    paddingVertical: 12,
    borderRadius: 8,
    backgroundColor: '#e0e0e0',
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonActive: {
    backgroundColor: '#1E90FF',
  },
  buttonText: {
    fontSize: 16,
    color: '#333',
  },
  buttonTextActive: {
    color: '#ffffff',
  },
  section: {
    padding: 16,
  },
  appointmentCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    marginVertical: 8,
    backgroundColor: '#fff',
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  imageContainer: {
    marginRight: 16,
  },
  image: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#ddd',
  },
  appointmentDetails: {
    flex: 1,
  },
  appointmentText: {
    fontSize: 16,
    color: '#333',
  },
});

export default AllAppointments;

import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Image, Text, ScrollView, TouchableOpacity, TouchableWithoutFeedback, Dimensions, Animated, FlatList } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';

const { width } = Dimensions.get('window');

const DoctorDashboard = ({ navigation, route }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { doctorId } = route.params; // Extracting doctorId from route params
  const [scrollX] = useState(new Animated.Value(0));
  const [appointments, setAppointments] = useState([]);
  const [patients, setPatients] = useState([]);

  useEffect(() => {
    fetchAppointments();
    fetchPatients();
  }, []);

  const fetchAppointments = async () => {
    try {
      const response = await fetch(`http://192.168.220.55/data/appts.php?doctorId=${doctorId}`);
      const data = await response.json();
      setAppointments(data);
    } catch (error) {
      console.error('Error fetching appointments:', error);
    }
  };

  const fetchPatients = async () => {
    try {
      const response = await fetch(`http://192.168.220.55/data/patient.php?doctorId=${doctorId}`);
      const data = await response.json();
      setPatients(data);
    } catch (error) {
      console.error('Error fetching patients:', error);
    }
  };

  const updateStatus = async (pid, status, date, time) => {
    try {
      const response = await fetch('http://192.168.220.55/data/status.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          pid,
          status,
          date,
          time,
          doctorId,
        }),
      });
      const result = await response.json();
      if (result.success) {
        console.log('Status updated successfully');
      } else {
        console.error('Error updating status:', result.error);
      }
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleViewAllAppointments = () => {
    navigation.navigate('all', { doctorId });
  };

  const handleSeeAll = () => {
    navigation.navigate('Patientlist', { doctorId });
  };

  const closeMenu = () => {
    if (isMenuOpen) {
      setIsMenuOpen(false);
    }
  };

  const handleAppointments = () => {
    console.log('Appointments clicked');
    // Navigate to Appointments screen or handle as needed
  };

  const handlePatientDetails = () => {
    console.log('Patient Details clicked');
    // Navigate to Patient Details screen or handle as needed
  };

  const handleAddPatient = () => {
    console.log('Add Patient clicked');
    // Navigate to Add Patient screen or handle as needed
  };

  const handleAddVideos = () => {
    console.log('Add Videos clicked');
    navigation.navigate('addvideos', { doctorId }); // Navigate to AddVideos screen
  };

  const handleLogout = () => {
    console.log('Logout clicked');
    // Handle logout functionality
  };

  const handlePatientPress = (patientId) => {
    console.log(`Patient ${patientId} clicked`);
    // Navigate to the patient detail screen or handle as needed
    navigation.navigate('Patientdetails', { patientId, doctorId });
  };

  const handleAccept = (pid, date, time) => {
    updateStatus(pid, 'accepted', date, time);
  };

  const handleReject = (pid, date, time) => {
    updateStatus(pid, 'rejected', date, time);
  };

  const renderPatientItem = ({ item }) => (
    <TouchableOpacity onPress={() => handlePatientPress(item.userId)}>
      <View style={styles.patientCard}>
        <View style={styles.cardHeader}>
          <Image
            resizeMode="cover"
            source={{
              uri: item.image,
            }}
            style={styles.cardImage}
          />
          <Text style={styles.cardName}>{item.name}</Text>
        </View>
        <View style={styles.cardContent}>
          <View style={styles.cardDetail}>
            <Text style={styles.cardSubText}>ID: {item.userId}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <TouchableWithoutFeedback onPress={closeMenu}>
      <View style={styles.container}>
        {isMenuOpen && <View style={styles.overlay} />}
        <View style={styles.header}>
          <TouchableOpacity style={styles.menuButton} onPress={toggleMenu}>
            <Ionicons name="menu-outline" size={44} color="black" />
          </TouchableOpacity>
          <View style={styles.headerTextContainer}>
            <Text style={styles.headerText}>Hello,</Text>
            <Text style={styles.headerText}>doctor</Text>
          </View>
          <TouchableOpacity style={styles.profileButton} onPress={() => console.log('Profile icon clicked')}>
            <Ionicons name="person-circle-outline" size={34} color="black" />
          </TouchableOpacity>
        </View>

        <View style={styles.imageContainer}>
          <Image
            resizeMode="cover"
            source={{
              uri: 'https://cdn.builder.io/api/v1/image/assets/TEMP/8320206088b08b7563dab73b12a25da27eb716f507b0e311c718418441f3792c?apiKey=ad53cdad426d4e138d822c19cfb9535b&',
            }}
            style={styles.mainImage}
          />
        </View>

        {isMenuOpen && (
          <View style={styles.menuContainer}>
            <TouchableOpacity style={styles.menuOption} onPress={handleAppointments}>
              <Text>Appointments</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.menuOption} onPress={handlePatientDetails}>
              <Text>Patient Details</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.menuOption} onPress={handleAddPatient}>
              <Text>Add Patient</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.menuOption} onPress={handleAddVideos}>
              <Text>Add Videos</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.menuOption} onPress={handleLogout}>
              <Text>Logout</Text>
            </TouchableOpacity>
          </View>
        )}

        <ScrollView contentContainerStyle={styles.scrollContent}>
          <View style={styles.section}>
            {/* Any additional section content can go here */}
          </View>

          <View style={styles.appointmentsContainer}>
            <View style={styles.appointmentsHeader}>
              <Text style={styles.appointmentsTitle}>Appointments</Text>
              <TouchableOpacity onPress={handleViewAllAppointments}>
                <Text style={styles.seeAllButton}>View all</Text>
              </TouchableOpacity>
            </View>
            <Animated.ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              snapToInterval={width * 0.8}
              decelerationRate="fast"
              contentContainerStyle={styles.cardsContainer}
              onScroll={Animated.event(
                [{ nativeEvent: { contentOffset: { x: scrollX } } }],
                { useNativeDriver: false }
              )}
              scrollEventThrottle={16}
            >
              {appointments.map((appointment, index) => {
                const inputRange = [
                  (index - 1) * width * 0.8,
                  index * width * 0.8,
                  (index + 1) * width * 0.8,
                ];
                const scale = scrollX.interpolate({
                  inputRange,
                  outputRange: [0.8, 1, 0.8],
                  extrapolate: 'clamp',
                });

                // Opacity based on scroll position
                const opacity = scrollX.interpolate({
                  inputRange,
                  outputRange: [0.5, 1, 0.5],
                  extrapolate: 'clamp',
                });

                return (
                  <Animated.View key={appointment.pid} style={[styles.card, { transform: [{ scale }], opacity }]}>
                    <View style={styles.cardHeader}>
                      <Image
                        resizeMode="cover"
                        source={{ uri: 'https://cdn.builder.io/api/v1/image/assets/TEMP/6486430a05f1e37aefe80286ddac1042dd3961d9a65ff608e12a78d3bfeffb33?apiKey=ad53cdad426d4e138d822c19cfb9535b&' }}
                        style={styles.cardImage}
                      />
                      <Text style={styles.cardName}>{appointment.name}</Text>
                    </View>
                    <View style={styles.cardContent}>
                      <View style={styles.cardDetail}>
                        <Text style={styles.cardSubText}>patientId: {appointment.pid}</Text>
                      </View>
                      <View style={styles.cardDetail}>
                        <Text style={styles.cardSubText}>Date: {appointment.date}</Text>
                      </View>
                      <View style={styles.cardDetail}>
                        <Text style={styles.cardSubText}>Time: {appointment.time}</Text>
                      </View>
                      <View style={styles.cardDetail}>
                        <Text style={styles.cardSubText}>doctorId: {appointment.did}</Text>
                      </View>
                    </View>
                    <View style={styles.buttonContainer}>
                      <TouchableOpacity style={[styles.button, styles.acceptButton]} onPress={() => handleAccept(appointment.pid, appointment.date, appointment.time)}>
                        <Text style={styles.buttonText}>Accept</Text>
                      </TouchableOpacity>
                      <TouchableOpacity style={[styles.button, styles.rejectButton]} onPress={() => handleReject(appointment.pid, appointment.date, appointment.time)}>
                        <Text style={styles.buttonText}>Reject</Text>
                      </TouchableOpacity>
                    </View>
                  </Animated.View>
                );
              })}
            </Animated.ScrollView>
          </View>

          <View style={styles.patientContainer}>
            <Text style={styles.patientHeader}>Patient Section</Text>
            <FlatList
              data={patients}
              renderItem={renderPatientItem}
              keyExtractor={(item) => item.userId.toString()}
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.patientList}
            />
          </View>
        </ScrollView>
      </View>
    </TouchableWithoutFeedback>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 40,
    paddingBottom: 10,
    backgroundColor: '#F6F6F6',
  },
  menuButton: {
    padding: 10,
  },
  headerTextContainer: {
    flex: 1,
    alignItems: 'center',
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  profileButton: {
    padding: 10,
  },
  imageContainer: {
    alignItems: 'center',
    marginVertical: 20,
  },
  mainImage: {
    width: '90%',
    height: 200,
    borderRadius: 10,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  menuContainer: {
    position: 'absolute',
    top: 90,
    left: 10,
    right: 10,
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 10,
    elevation: 5,
    zIndex: 1,
  },
  menuOption: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  scrollContent: {
    paddingBottom: 20,
  },
  section: {
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  appointmentsContainer: {
    marginBottom: 20,
  },
  appointmentsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 10,
  },
  appointmentsTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  seeAllButton: {
    fontSize: 16,
    color: '#007BFF',
  },
  cardsContainer: {
    paddingHorizontal: 10,
  },
  card: {
    width: width * 0.8,
    marginHorizontal: 10,
    backgroundColor: '#FFF',
    borderRadius: 10,
    overflow: 'hidden',
    elevation: 3,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
  },
  cardImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 10,
  },
  cardName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  cardContent: {
    padding: 10,
  },
  cardDetail: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  cardSubText: {
    fontSize: 16,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
  },
  button: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  acceptButton: {
    backgroundColor: '#28A745',
    marginRight: 5,
  },
  rejectButton: {
    backgroundColor: '#DC3545',
    marginLeft: 5,
  },
  buttonText: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  patientContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  patientHeader: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  patientList: {
    paddingVertical: 10,
  },
  patientCard: {
    width: width * 0.8,
    marginRight: 10,
    backgroundColor: '#FFF',
    borderRadius: 10,
    overflow: 'hidden',
    elevation: 3,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
  },
  cardImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 10,
  },
  cardName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  cardContent: {
    padding: 10,
  },
  cardDetail: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  cardSubText: {
    fontSize: 16,
  },
});

export default DoctorDashboard;

<?php
// Update status of an appointment

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project1";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);
$pid = $data['pid'];
$status = $data['status'];

// Prepare and execute the query
$stmt = $conn->prepare("UPDATE appt SET status = ? WHERE pid = ?");
$stmt->bind_param("si", $status, $pid);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $stmt->error]);
}

$stmt->close();
$conn->close();
?>

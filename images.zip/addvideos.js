import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, TextInput, StyleSheet, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as ImagePicker from 'expo-image-picker';
import RNPickerSelect from 'react-native-picker-select';
import { useNavigation, useRoute } from '@react-navigation/native'; // Import navigation and route hooks

function UploadVideo() {
  const navigation = useNavigation(); // Access navigation object
  const route = useRoute(); // Access route object
  const { doctorId } = route.params; // Extracting doctorId from route params
  const [introduction, setIntroduction] = useState('');
  const [customFileName, setCustomFileName] = useState('');
  const [video, setVideo] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [subOption, setSubOption] = useState('');
  const [subOptions, setSubOptions] = useState([]);

  const pickVideo = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Videos,
      allowsEditing: true,
      quality: 1,
    });

    if (!result.cancelled) {
      setVideo(result.assets[0]);
    }
  };

  useEffect(() => {
    if (selectedCategory === 'Demo') {
      setSubOptions([]);
    } else if (selectedCategory === 'Spinal Level') {
      setSubOptions([
        { label: 'L2', value: 'L2' },
        { label: 'L3', value: 'L3' },
        { label: 'L4', value: 'L4' },
        { label: 'L5', value: 'L5' },
        { label: 'S1', value: 'S1' },
        { label: 'S2', value: 'S2' },
      ]);
    } else {
      setSubOptions([]);
    }
  }, [selectedCategory]);

  const handleUpload = async () => {
    if (!video || !introduction || !customFileName || !selectedCategory || (selectedCategory === 'Spinal Level' && !subOption)) {
      Alert.alert('Please fill all the fields, select a video, and choose options.');
      return;
    }

    const formData = new FormData();
    formData.append('video_file', {
      uri: video.uri,
      name: `${customFileName}_${video.uri.split('/').pop()}`,
      type: 'video/mp4', // Adjust type as necessary
    });
    formData.append('introduction', introduction);
    formData.append('custom_file_name', customFileName);
    formData.append('category', selectedCategory);
    if (selectedCategory === 'Spinal Level') {
      formData.append('sub_option', subOption);
    }

    let serverUrl = '';
    if (selectedCategory === 'Demo') {
      serverUrl = 'http://192.168.220.55/data/demo.php';
    } else if (selectedCategory === 'Spinal Level') {
      serverUrl = 'http://192.168.220.55/data/spinallevels.php'; // Change the URL accordingly
    }

    try {
      const response = await fetch(serverUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        body: formData,
      });

      const responseData = await response.json();
      console.log(responseData);
      Alert.alert('Upload Successful', responseData.message);

      // Navigate to Doctor Dashboard after successful upload
      navigation.navigate('Doctordashboard', { doctorId }); // Replace 'DoctorDashboard' with your actual screen name
    } catch (error) {
      console.error('Error:', error);
      Alert.alert('Error', 'Something went wrong. Please try again later.');
    }
  };

  return (
    <LinearGradient colors={['#33EC75', '#fff']} style={styles.container}>
      <View style={styles.view2}>
        <Text style={styles.text1}>Upload Video</Text>
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Introduction"
            value={introduction}
            onChangeText={setIntroduction}
          />
          <TextInput
            style={styles.input}
            placeholder="Custom File Name"
            value={customFileName}
            onChangeText={setCustomFileName}
          />
          <RNPickerSelect
            onValueChange={(value) => setSelectedCategory(value)}
            items={[
              { label: 'Demo', value: 'Demo' },
              { label: 'Spinal Level', value: 'Spinal Level' },
            ]}
            placeholder={{ label: "Select Category", value: null }}
            style={pickerSelectStyles}
          />
          {selectedCategory === 'Spinal Level' && (
            <RNPickerSelect
              onValueChange={(value) => setSubOption(value)}
              items={subOptions}
              placeholder={{ label: "Select Option", value: null }}
              style={pickerSelectStyles}
            />
          )}
        </View>
        <TouchableOpacity style={styles.button} onPress={pickVideo}>
          <Text style={styles.buttonText}>Pick a Video</Text>
        </TouchableOpacity>
        {video && <Text style={styles.fileName}>{video.uri.split('/').pop()}</Text>}
        <TouchableOpacity style={styles.button} onPress={handleUpload}>
          <Text style={styles.buttonText}>Upload Video</Text>
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
}

const pickerSelectStyles = StyleSheet.create({
  inputIOS: {
    fontSize: 16,
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 10,
    color: 'black',
    paddingRight: 30, // to ensure the text is never behind the icon
    marginBottom: 10,
    backgroundColor: '#FFF',
  },
  inputAndroid: {
    fontSize: 16,
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 10,
    color: 'black',
    paddingRight: 30, // to ensure the text is never behind the icon
    marginBottom: 10,
    backgroundColor: '#FFF',
  },
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  view2: {
    borderRadius: 20,
    width: '90%',
    alignItems: 'center',
    padding: 20,
  },
  text1: {
    color: '#FFFFFF',
    textAlign: 'center',
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    marginBottom: 20,
    width: '100%',
  },
  input: {
    width: '100%',
    height: 55,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 10,
    marginBottom: 10,
    backgroundColor: '#FFF',
  },
  button: {
    borderRadius: 10,
    backgroundColor: '#019874',
    paddingVertical: 14,
    paddingHorizontal: 30,
    marginBottom: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
  },
  fileName: {
    color: '#333',
    fontSize: 16,
    marginBottom: 10,
  },
});

export default UploadVideo;

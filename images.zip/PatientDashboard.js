import React, { useRef, useEffect, useState } from "react";
import { View, StyleSheet, ScrollView, Image, Text, TouchableOpacity, Dimensions, Modal, TouchableWithoutFeedback } from "react-native";
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

const { width } = Dimensions.get('window');

function PatientDashboard({ route }) {
  const { userId } = route.params;
  const navigation = useNavigation();
  const scrollViewRef = useRef(null);
  const [menuVisible, setMenuVisible] = useState(false);
  let scrollPosition = 0;

  const images = [
    require('./images/back1.jpg'),
    require('./images/back2.jpg'),
    require('./images/back3.jpg'),
    require('./images/back4.jpg'),
    require('./images/back5.jpg')
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      if (scrollViewRef.current) {
        scrollPosition = (scrollPosition + width) % (images.length * width);
        scrollViewRef.current.scrollTo({ x: scrollPosition, animated: true });
      }
    }, 2000);
    return () => clearInterval(interval);
  }, []);


  const handleViewAllPress = () => {
    navigation.navigate('ViewAll');
  };

  const handleProfilePress = () => {
    navigation.navigate('PatientProfile');
  };

  const handleL2Press = () => {
    navigation.navigate('L2Spine');
  };

  const handleL3Press = () => {
    navigation.navigate('L3Spine');
  };

  const handleL4Press = () => {
    navigation.navigate('L4Spine');
  };

  const handleL5Press = () => {
    navigation.navigate('L5Spine');
  };

  const handleBookAppointmentPress = () => {
    navigation.navigate('PatientAppointment', { userId });
  };
  
  

  const toggleMenu = () => {
    setMenuVisible(!menuVisible);
  };

  const closeMenu = () => {
    setMenuVisible(false);
  };

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <TouchableOpacity style={styles.menuIconContainer} onPress={toggleMenu}>
          <Ionicons name="menu" size={40} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerText}>Welcome</Text>
        <TouchableOpacity style={styles.profileImageContainer} onPress={handleProfilePress}>
          <Image
            source={require('./images/profile.png')}
            style={styles.profileImage}
          />
        </TouchableOpacity>
      </View>

      <Modal
        animationType="none"
        transparent={true}
        visible={menuVisible}
        onRequestClose={toggleMenu}
      >
        <TouchableWithoutFeedback onPress={closeMenu}>
          <View style={styles.menuOverlay}>
            <TouchableWithoutFeedback>
              <View style={styles.menuContainer}>
                <TouchableOpacity style={styles.menuItem} onPress={() => { closeMenu(); navigation.navigate('ViewAll'); }}>
                  <Text style={styles.menuItemText}>Spine Levels</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.menuItem} onPress={() => { closeMenu(); navigation.navigate('PatientAppointment'); }}>
                  <Text style={styles.menuItemText}>Appointment booking</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.menuItem} onPress={() => { closeMenu(); /* Add your action here */ }}>
                  <Text style={styles.menuItemText}>Movement Level</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.menuItem} onPress={() => { closeMenu(); navigation.navigate('Welcome'); }}>
                  <Text style={styles.menuItemText}>Logout</Text>
                </TouchableOpacity>
              </View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>

      <View style={styles.topImage}>
        <ScrollView
          ref={scrollViewRef}
          horizontal={true}
          contentContainerStyle={styles.headerImageContainer}
          showsHorizontalScrollIndicator={false}
          pagingEnabled
        >
          {images.map((image, index) => (
            <Image
              key={index}
              source={image}
              style={styles.headerImage}
            />
          ))}
        </ScrollView>
      </View>

      <View style={styles.move}>
        <Text style={styles.headerImageTextLeft}>LS Spine Levels</Text>
        <TouchableOpacity style={styles.headerImageTextRight} onPress={handleViewAllPress}>
          <Text>View All</Text>
        </TouchableOpacity>
      </View>

      <LinearGradient
        colors={['#fff', '#5ADC99', '#fff']} // Replace with your desired gradient colors
        style={styles.rowContainer}
      >
        <ScrollView horizontal={true}>
          <TouchableOpacity style={styles.imageButton} onPress={handleL2Press}>
            <Image
              resizeMode="contain"
              source={{
                uri: "https://cdn.builder.io/api/v1/image/assets/TEMP/ed1cc74585963108e7eda741cf983da7d61173b96f5182e2b23a3a817d1152a2?apiKey=ad53cdad426d4e138d822c19cfb9535b&",
              }}
              style={styles.image}
            />
            <Text style={styles.text}>L2</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.imageButton} onPress={handleL3Press}>
            <Image
              resizeMode="contain"
              source={{
                uri: "https://cdn.builder.io/api/v1/image/assets/TEMP/6fcd04d4f0e9f8ff4e916c88502be36be23214e7ef73d9513b616d2b03cde425?apiKey=ad53cdad426d4e138d822c19cfb9535b&",
              }}
              style={styles.image}
            />
            <Text style={styles.text}>L3</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.imageButton} onPress={handleL4Press}>
            <Image
              resizeMode="contain"
              source={{
                uri: "https://cdn.builder.io/api/v1/image/assets/TEMP/ed1cc74585963108e7eda741cf983da7d61173b96f5182e2b23a3a817d1152a2?apiKey=ad53cdad426d4e138d822c19cfb9535b&",
              }}
              style={styles.image}
            />
            <Text style={styles.text}>L4</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.imageButton} onPress={handleL5Press}>
            <Image
              resizeMode="contain"
              source={{
                uri: "https://cdn.builder.io/api/v1/image/assets/TEMP/6fcd04d4f0e9f8ff4e916c88502be36be23214e7ef73d9513b616d2b03cde425?apiKey=ad53cdad426d4e138d822c19cfb9535b&",
              }}
              style={styles.image}
            />
            <Text style={styles.text}>L5</Text>
          </TouchableOpacity>
        </ScrollView>
      </LinearGradient>

      <View style={styles.footerContainer}>
        <View style={styles.button}>
          <Image
            resizeMode="contain"
            source={{
              uri: "https://cdn.builder.io/api/v1/image/assets/TEMP/bbc226de8698b973bb137cc8d3cef475fe220475e9ec9024767330cc5a686529?apiKey=ad53cdad426d4e138d822c19cfb9535b&",
            }}
            style={styles.footerImage}
          />
        </View>
        <View style={styles.footerContent}>
          <Text style={styles.doctorName}>DR.Raj Kumar</Text>
          <Text style={styles.specialization}>Ortho</Text>
          <TouchableOpacity style={styles.bookAppointmentButton} onPress={handleBookAppointmentPress}>
            <Text style={styles.buttonText}>Book appointments</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFF",
    //alignItems: "center",
  },
  headerContainer: {
    flexDirection: "row",
    height:110,
    //alignItems: "center",
    //justifyContent: "space-between",
    //paddingVertical: 20,
    //marginTop: 10,
  },
  menuIconContainer: {
    //position: 'absolute',
    flex:1,
    alignItems:'center',
    justifyContent:'center',
    width:20,
   // height:80,
    top: 18,
   left: -20,
  },
  headerText: {
    flex:0,
    alignItems:'center',
    justifyContent:'center',
    
    fontSize: 40,
    fontWeight: "bold",
    marginTop: 45,
  },
  profileImageContainer: {
    flex:1,
    left:60,
    marginTop: 50,
  },
  
  profileImage: {
    width: 40,
    height: 40,
    borderRadius: 50,
  },
  headerImageContainer: {
   width:'500%',
  },
  topImage:{
      width:'100%',


  },
  headerImage: {
    width:200,
    height: 200,
    margin:20,
    borderRadius: 30, // Added borderRadius here
  },
  headerImageTextLeft: {
    fontSize: 27,
    fontWeight: "bold",
    marginRight: 150,
  },
  headerImageTextRight: {
    fontSize: 24,
    fontWeight: "bold",
    textDecorationLine: 'underline',
  },
  move: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 20,
  },
  rowContainer: {
    flexDirection: "row",
    marginBottom: 90,
    borderRadius: 0, // Optional: Add border radius for rounded corners
  },
  text: {
    fontSize: 26,
    fontWeight: "bold",
    marginTop: 10,
  },
  image: {
    width: 160,
    height: 190,
  },
  imageButton: {
    marginRight: 10,
    alignItems: "center",
  },
  footerContainer: {
    alignItems: "center",
    marginBottom: 30,
    flexDirection: "row",
    backgroundColor: "white",
    marginHorizontal: 10,
    marginVertical: -45,
    borderRadius: 20, 
  },
  button: {
    alignItems: "center",
    backgroundColor: "white",
    padding: 1,
    borderRadius: 20,
    flex: 1,
    marginTop:10,
    marginBottom: 10,
  },
  footerImage: {
    width: 150,
    height: 150,
    marginLeft: -10.5,
    borderRadius:120,
  },
  footerContent: {
    alignItems: "center",
    flexDirection: "column",backgroundColor:'cyan',
  },
  doctorName: {
    fontSize: 20,
    fontWeight: "bold",
    marginTop: 20, 
  },
  specialization: {
    fontSize: 16,
    fontWeight: "bold",
  },
  bookAppointmentButton: {
    marginLeft: 15,
    backgroundColor: "#5ADC99",
    paddingHorizontal: 20,
    paddingVertical: 15,
    flex: 1,
    marginTop: 20,
    borderRadius:50,
  },
  buttonText: {
    fontWeight: "bold",
    fontSize: 25,
  },
  menuOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-end', // Aligns the menu to the right
  },
  menuContainer: {
    backgroundColor: 'white',
    padding: 10,
    borderRadius: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 5,
    position: 'absolute',
    top: 80,
    left: 0,
  },
  menuItem: {
    paddingVertical: 10,
    paddingHorizontal: 20,
  },
  menuItemText: {
    fontSize: 16,
  },
});

export default PatientDashboard;

module.exports = {
    resolver: {
      // Add your resolver options here
    },
    transformer: {
      // Add your transformer options here
    },
    server: {
      // Set the correct IP address
      port: 8081,
      useIPv6: false,
      host: '192.168.220.55'
    }
  };
  
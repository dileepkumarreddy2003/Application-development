import React, { useEffect, useState } from 'react';
import { View, StyleSheet, TouchableOpacity, Text, FlatList, Dimensions, ActivityIndicator } from 'react-native';
import { Video } from 'expo-av';
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

export default function VideoListScreen({ route }) {
  const { userId } = route.params;
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigation = useNavigation();

  useEffect(() => {
    fetchVideos();
  }, []);

  const fetchVideos = async () => {
    try {
      const response = await fetch('http://192.168.220.55/data/videodisplay.php', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
      }

      const result = await response.json();
      if (result.success) {
        setVideos(result.data);
      } else {
        setError(result.message);
      }
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAddVideo = () => {
    navigation.navigate('PatientDashboard', { userId });
  };

  const renderVideoItem = ({ item }) => {
    if (!item) {
      return (
        <View style={styles.videoContainer}>
          <Text style={styles.errorText}>Invalid item</Text>
        </View>
      );
    }

    const { video_path, introduction, custom_file_name } = item;

    return (
      <View style={styles.videoContainer}>
        <Video
          source={{ uri: video_path }}
          style={styles.video}
          useNativeControls
          resizeMode="contain"
          onError={(error) => console.error('Video loading error:', error)}
        />
        <View style={styles.textContainer}>
          <Text style={styles.introText}>Introduction: {introduction ? introduction : 'No Introduction'}</Text>
          <Text style={styles.fileNameText}>Custom File Name: {custom_file_name ? custom_file_name : 'No File Name'}</Text>
        </View>
      </View>
    );
  };

  const keyExtractor = (item, index) => {
    if (item && item.id) {
      return item.id.toString();
    }
    return index.toString();
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2DC2D7" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>{error}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={videos}
        renderItem={renderVideoItem}
        keyExtractor={keyExtractor}
      />
      <TouchableOpacity style={styles.addButton} onPress={handleAddVideo}>
        <Text style={styles.addButtonText}>NEXT</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#CDF5FD',
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  videoContainer: {
    marginBottom: 20,
    alignItems: 'center',
    width: width * 0.9,
  },
  video: {
    width: '100%',
    height: height * 0.3,
  },
  textContainer: {
    flex: 1,
    paddingHorizontal: 10,
    alignItems: 'center',
  },
  introText: {
    fontSize: 16,
    marginBottom: 5,
    fontWeight: 'bold',
  },
  fileNameText: {
    fontSize: 16,
    marginBottom: 5,
    fontWeight: 'bold',
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    paddingVertical: 10,
    borderRadius: 40,
    marginHorizontal: 20,
    marginTop: 20,
    elevation: 3,
  },
  addButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2DC2D7',
    marginLeft: 5,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    fontSize: 18,
    color: 'red',
  },
});
